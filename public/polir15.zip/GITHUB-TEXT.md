# GITHUB-TEXT.md — pripravljeno za lepljenje v discover-slovenia-ai

## 1) Komentar na issue #34 (status implementacije)

```markdown
### POLIR15 — status (faza raziskava → specifikacija → implementacija ✅)

Vse štiri točke so implementirane v referenčnem okolju (Next.js 16, App Router,
Tailwind 4, shadcn/ui, Leaflet) in preverjene E2E v brskalniku:

- [x] **a — Sticky preklop (z-index nasprotje z Leafletom)**
      Mapa zaprta v stacking context (`relative z-0 isolate`), preklop
      `sticky top-14 z-30`. Leaflet CSS nespremenjen. Preverjeno: klik čez mapo.
- [x] **b — Sezonska afiniteta heroja (vrzel #3)**
      SSR resolver po MMDD oknih (+ ovitek čez leto), izvorni SI mikro-dogodki
      (martinovanje, kurentovanje, december) — zgled: ST sezonski koledar,
      Tourism Ireland "Home of Halloween". 4 sezonske variante + slike.
- [x] **c — PersonalHomeSection CLS (getServerSession waterfall)**
      `cache(() => getServerSession(...))` dedup + `Promise.all` paralelizacija +
      streaming prek `<Suspense>` s strukturno identičnim skeletom. Preverjeno:
      sekcija streamira brez premika zemljevida.
- [x] **d — CLS skeleta zemljevida (0,023 → 0)**
      Enoten vir višine (`h-[420px] md:h-[520px]`), vsebina `absolute inset-0`,
      skeleton sproščen ob `tileLayer 'load'` (+3 s varovalka).

Koda: pripravljena v prenosnem paketu (`polir15.zip`), vključno z integracijskimi
koraki in DoD checklisto.
```

## 2) Branch in commit serija

```bash
git checkout -b polir15

# 1. commit — POLIR15-a/d
git add src/components/home/map-section.tsx
git commit -m "fix(map): izoliraj Leaflet stacking context (z-0) in enoten vir višine (CLS 0.023→0)

- sticky preklop (top-14, z-30) ostane klikaben nad mapo
- skeleton in vsebina absolutna znotraj fiksne škatle
- Refs #34"

# 2. commit — POLIR15-b
git add src/lib/seasonal-hero.ts src/components/home/hero-section.tsx public/images/hero-*.png
git commit -m "feat(hero): sezonska afiniteta (SSR MMDD okna + SI mikro-dogodki)

- winter/spring/summer/autumn variante z ovitkom čez leto
- martinovanje / kurentovanje / december overlay
- fiksno aspect-ratio (CLS 0), ISR revalidate 3600
- Refs #34"

# 3. commit — POLIR15-c
git add src/components/home/personal-home-section.tsx src/app/api/demo-session/route.ts src/components/home/session-toggle.tsx
git commit -m "perf(personal): streamirana sekcija z rezerviranim skeletom (CLS 0)

- session dedup prek React cache() + Promise.all (brez waterfalla)
- strukturno identičen skeleton (h-7 naslov, h-[140px] kartice)
- Refs #34"

git push -u origin polir15
```

## 3) Naslov PR-ja

```
POLIR15: sticky preklop nad Leafletom, sezonski hero, PersonalHomeSection CLS, CLS skeleta zemljevida
```

## 4) Telo PR-ja

```markdown
Closes #34

## Povzetek
- **POLIR15-a:** Leaflet zaprt v `relative z-0 isolate`; sticky preklop `top-14 z-30`; brez sprememb Leaflet CSS.
- **POLIR15-b:** `lib/seasonal-hero.ts` — SSR resolver (MMDD okna), mikro-dogodki (martinovanje/kurentovanje/december), 4 hero variantе + slike; `revalidate = 3600`.
- **POLIR15-c:** session dedup (React `cache()`) + `Promise.all`; sekcija streamirana prek `<Suspense>` z identičnim skeletom → brez premika.
- **POLIR15-d:** enoten vir višine mape (`MAP_H`); skeleton/seznam/mapa `absolute inset-0`; CLS 0,023 → 0.

## Testiranje
- [x] E2E v brskalniku: preklop nad mapo, drag/zoom, prijava → streaming brez premika
- [x] Mobilni 390 px in namizni 1280 px
- [x] `?season=` override za vse štiri sezone
- [ ] Lighthouse CLS = 0 (produkcija) — po merge
```

## 5) Samodejno zaprtje issue-ja
Beseda `Closes #34` v telesu PR-ja (privzeta veja) zapre issue ob merge-u.
