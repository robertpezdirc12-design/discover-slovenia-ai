# POLIR15 — prenosni paket (issue #34, discover-slovenia-ai)

Referenčna implementacija vseh štirih točk, delujoča na Next.js 16 (App Router) +
Tailwind 4 + shadcn/ui + Leaflet. Struktura datotek ustreza `src/` mapi tvojega
projekta — kopiraj in prilagodi uvozne poti po potrebi.

## Vsebina

| Datoteka | Točka | Kaj rešuje |
|---|---|---|
| `src/lib/seasonal-hero.ts` | POLIR15-b | SSR sezonski resolver (MMDD okna + SI mikro-dogodki), konfiguracijska tabela hero variant |
| `src/components/home/map-section.tsx` | POLIR15-a + d | Sticky preklop nad izolirano Leaflet mapo (`z-0 isolate`) + enoten vir višine (CLS 0) |
| `src/components/home/personal-home-section.tsx` | POLIR15-c | Streamirana osebna sekcija + strukturno identičen skeleton (CLS 0) |
| `src/components/home/hero-section.tsx` | POLIR15-b | Sezonski hero z fiksnim aspect-ratio (brez CLS) |
| `src/components/home/session-toggle.tsx` | POLIR15-c | Demo preklop prijave (v produkciji zamenjaj z next-auth UI) |
| `src/components/home/site-header.tsx` | — | Lepljiva glava (h-14, z-40) — referenčni odmik za sticky vrstico |
| `src/components/home/proof-section.tsx` | — | Povzetek dokazov (lahko izpustiš) |
| `src/app/api/demo-session/route.ts` | POLIR15-c | Demo seja prek cookie (v produkciji nadomesti z next-auth) |
| `GITHUB-TEXT.md` | #34 | Komentar na issue, commit serija, naslov in telo PR-ja (Closes #34) |

## Integracija v discover-slovenia-ai

### POLIR15-a — sticky preklop vs. Leaflet z-index
1. V svojem `MapSection` ovij `<MapContainer>` v wrapper z razredi `relative z-0 isolate`.
2. Sticky preklop: `sticky top-14 z-30` (top-14 = višina tvoje lepljive glave; z-30 > z-0 kontekst mape).
3. NE spreminjaj `z-index` v Leaflet CSS (lomi plugin-e) in NE dviguj sticky nad 1000.

### POLIR15-b — sezonska afiniteta heroja
1. Kopiraj `src/lib/seasonal-hero.ts`; vsebino (`SEASONAL_HERO`) prilagodi svojim destinacijam.
2. Hero naj bo server component: `const { variant, microEvent } = getHeroVariant()`.
3. V hero strani dodaj `export const revalidate = 3600` (ISR — sezona se osveži vsaj vsako uro).
4. Slike: `/public/images/hero-{winter,spring,summer,autumn}.png` (iz demo strani).

### POLIR15-c — PersonalHomeSection CLS
1. `lib/auth-cache.ts` (dodaj v svoj repo):
   ```ts
   import { cache } from 'react';
   import { getServerSession } from 'next-auth';
   import { authOptions } from '@/lib/auth';
   export const getSession = cache(() => getServerSession(authOptions));
   ```
2. V strani: `const [session, data] = await Promise.all([getSession(), getData()])` — brez waterfalla.
3. Sekcijo lovi prek `<Suspense fallback={<PersonalHomeSkeleton />}>`; skeleton in sekcija imata
   identično strukturo (h-7 naslov, h-[140px] kartice) → zamenjava ne premakne ničesar.
4. Session bralec enkrat, prop navzdol.

### POLIR15-d — CLS skeleta zemljevida 0,023 → 0
1. Enoten vir višine: `const MAP_H = 'h-[420px] md:h-[520px]'` (ali CSS var `--map-h`).
2. Skeleton IN vsebina (mapa/seznam): `absolute inset-0` znotraj wrapperja z `MAP_H`.
3. Skeleton sprosti ob Leaflet `tileLayer.on('load')` + varovalka 3 s timeout.
4. Prepričaj se, da `dynamic(..., { ssr: false })` ne spreminja višine wrapperja.

## Odvisnosti
```
bun add leaflet
bun add -d @types/leaflet
```

## Preverjanje (Definition of Done)
- [ ] Sticky preklop klikaben nad zemljevidom med drsenjem (drag ne sežane čez vrstico)
- [ ] Hero varianta ustreza datumu (MMDD okna); `?season=` override samo za demo
- [ ] Lighthouse CLS = 0 za prijavljenega uporabnika in za zemljevid
- [ ] Skeleton zemljevida in realna mapa imata piksloma enako višino
- [ ] Brez sprememb v Leaflet CSS

## Hitra pot prek GitHuba (glej GITHUB-TEXT.md)
1. Komentar statusa nalepi na issue #34.
2. `git checkout -b polir15` → kopiraj datoteke → commit serija iz GITHUB-TEXT.md → push.
3. Odpri PR z naslovom in telesom iz GITHUB-TEXT.md (`Closes #34`).
